from setuptools import setup

setup(
    name='utils',
    version='0.0.1',
    description='ipython DL utils',
    packages=['utils'],
    author='Yoav Orlev',
    author_email='yoav.orlev@gmail.com',
    keywords=['utils'],
    url='https://'
)