from setuptools import setup

setup(
    name='trainers',
    version='0.0.1',
    description='PyTorch DL trainers',
    packages=['trainers'],
    author='Yoav Orlev',
    author_email='yoav.orlev@gmail.com',
    keywords=['trainers'],
    url='https://'
)